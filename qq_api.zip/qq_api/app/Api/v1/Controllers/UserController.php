<?php

namespace App\Api\v1\Controllers;

use Dingo\Api\Routing\Helpers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
///JWT
use Firebase\JWT\ExpiredException;
use Firebase\JWT\JWT;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    public function login(Request $request)
    {   
        if(Hash::check($request->password,DB::table('account')->where('username',$request->username)->value('password'))){
            
            $payload = [ //主內容
                    'iss' => "lumen-jwt", // 簽發人
                    'username' => $request->username,
                    'iat' => time(), // 簽發時間 
                    'exp' => time() + 1 // 過期時間 以秒為單位
                    // 'sub' => '123', // 主題
                    // 'aud' => "", //使用對象
                    // 'nbf' => "", // 生效時間
            ];
            $token = JWT::encode($payload, env('JWT_SECRET')); //用JWTPrivacyKey加密 生成token
            $response = [
                'status_code' => '200',
                'token' =>  $token,
            ]; 
        }else{
            $response = "fail";
        }
		return $response;
    }
    public function refreshtoken(Request $request){

        $token = substr($request->headers->get('Authorization'),7);
        $data = JWT::decode($oldtoken,env('JWT_SECRET'),array('HS256'));

        $payload = [ //主內容
            'iss' => "lumen-jwt", // 簽發人
            'username' => $request->username,
            'iat' => time(), // 簽發時間 
            'exp' => time() + 1 // 過期時間 以秒為單位
            // 'sub' => '123', // 主題
            // 'aud' => "", //使用對象
            // 'nbf' => "", // 生效時間
        ];
        $response = [
            'status_code' => '200',
            'token' =>  $token,
        ];
        return $response;

    }
}
