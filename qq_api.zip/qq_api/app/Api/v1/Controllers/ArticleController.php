<?php

namespace App\Api\v1\Controllers;

use Dingo\Api\Routing\Helpers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class ArticleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    public function index(Request $request)
    {   
        if($request->language == 'en'){
            $data = [
                'title' => DB::table('article')->where('code',$request->code)->where('type',1)->value('code'),
                'body' => DB::table('article')->where('code',$request->code)->where('type',1)->value('body'),
            ];
        }else{
            $code = $request->code . "_" . $request->language;
            $data = [
                'title' => DB::table('article')->where('code',$code)->where('type',1)->value('code'),
                'body' => DB::table('article')->where('code',$code)->where('type',1)->value('body'),
            ];
        }
        //$title = DB::select('select * from users where active = ?', [1]);
        //$body = DB::select('select * from users where active = ?', [1]);
		// //$code = (\App::getLocale() == 'en') ? 'ABOUTUS' : 'ABOUTUS_'.\App::getLocale();
		// if($article = Article::whereCode($code)->first()) {	
		// 	$data = ['article' => $article];
        // }
        $response = $data;
		return $response;
    }
    //
}
