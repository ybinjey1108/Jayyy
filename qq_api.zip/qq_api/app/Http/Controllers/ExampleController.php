<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use DB;

class ExampleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }
    public function handle(){
        return 'handle';
    }
    public function test(){
        $code = 'ABOUTUS';
        $data = DB::table('article')->where('code',$code)->where('type',1)->get();

        return $data;
        }
    //
}
