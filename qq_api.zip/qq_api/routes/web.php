<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$api = app('Dingo\Api\Routing\Router'); //讓dingo接管api路由

$api->version('v1',function($api){

    // $api->get('version', function() {          //版本檢驗
    //     return response('this is version v1');
    // });
    $api->group(['middleware' => 'api.Client'],function($api){
        $api->post('article','App\Api\v1\Controllers\ArticleController@index'); //Article
        $api->post('test','App\Http\Controllers\ExampleController@handle'); //Example
        $api->post('members/login','App\Api\v1\Controllers\UserController@login'); //login
    });
    $api->group(['middleware' => 'api.auth'],function($api){
        
    });
    $api->post('members/refreshtoken','App\Api\v1\Controllers\UserController@refreshtoken'); //refreshtoken
}); 
